package com.example.climbup

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
